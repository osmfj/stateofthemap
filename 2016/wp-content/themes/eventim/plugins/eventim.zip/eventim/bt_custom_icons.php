<?php
function bt_custom_icons() {
	/*$arr = array( 
		'24-hrs (custom)' => 'cs_' . 'e604',
		'24-full-circle (custom)' => 'cs_' . 'e605'
	);*/

	$arr = array(
		
	);
	
	ksort( $arr );

	return $arr;
}